<?php
if ($_GET['randomId'] != "dkbSISsDSS3yAdVkbFgRjrm33tglH6GADHZa6Ug74m_f0_1DBeXdb7cW5NLk3_Hw") {
    echo "Access Denied";
    exit();
}

// display the HTML code:
echo stripslashes($_POST['wproPreviewHTML']);

?>  
