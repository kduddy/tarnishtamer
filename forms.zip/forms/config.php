<?php
//this file includes the settings of form captcha
$error = 'security code is not correct'  ;
$error_display_mode = 0 ;
$error_page=  '' ;
$font_size =  16  ;
$hight = 60  ;
$width =  240  ;
$text_length = 7  ;
$font_file =  'CENTURY.TTF' ;
$border =  0  ;
$form =  'example.html'  ;
$CaseSenstive = false  ;
$user = 'admin'  ;
$pass =  '21232f297a57a5a743894a0e4a801fc3' ;
$redirect = false ;
$success_page = ''  ;
?>